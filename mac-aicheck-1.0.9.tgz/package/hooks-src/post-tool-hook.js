#!/usr/bin/env node
// mac-aicheck-hook-version: 2.0.0
// PostToolUse hook: 捕获 Bash/Agent 执行结果，提取命令分类和错误信号
// 从 stdin 读取 hook payload

const { existsSync, mkdirSync, appendFileSync, readFileSync, writeFileSync } = require('fs');
const { join } = require('path');
const { homedir } = require('os');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

function getHome() { return process.env.HOME || homedir(); }
const BASE_DIR = join(getHome(), '.mac-aicheck');
const OUTBOX_FILE = join(BASE_DIR, 'outbox', 'events.jsonl');
const EXPERIENCE_FILE = join(BASE_DIR, 'experience.jsonl');
const DAILY_DIR = join(BASE_DIR, 'daily');

function ensureDir(dir) {
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
}

function nowIso() { return new Date().toISOString(); }
function today() { return nowIso().slice(0, 10); }

function shortHash(v) {
  return crypto.createHash('sha256').update(v).digest('hex').slice(0, 16);
}

// ── 命令分类 ──
function classifyCommand(cmd) {
  const c = String(cmd || '').trim().toLowerCase();
  if (/^git\s/.test(c) || c === 'git') return 'git';
  if (/^npm\s|^npx\s|^yarn\s|^pnpm\s/.test(c)) return 'npm';
  if (/^node\s|^bun\s|^deno\s/.test(c)) return 'node';
  if (/^python\s|^python3\s|^pip\s|^pip3\s|^poetry\s|^uv\s/.test(c)) return 'python';
  if (/^brew\s/.test(c)) return 'brew';
  if (/^docker\s|^podman\s/.test(c)) return 'docker';
  return 'shell';
}

// ── 错误信号提取 ──
function extractErrorSignals(msg) {
  const t = String(msg || '').toLowerCase();
  const signals = [];
  if (/econnrefused|connection refused/i.test(t)) signals.push('network_connection_refused');
  if (/etimedout|timed?\s*out|timeout/i.test(t)) signals.push('network_timeout');
  if (/sigkill|sigterm|killed|terminated/i.test(t)) signals.push('process_terminated');
  if (/max.?token|context.?overflow|context.?window|token.?limit/i.test(t)) signals.push('context_overflow');
  if (/rate.?limit|429|too many requests/i.test(t)) signals.push('rate_limited');
  if (/eacces|permission denied|operation not permitted/i.test(t)) signals.push('permission_denied');
  if (/command not found|enoent|not found/i.test(t)) signals.push('command_not_found');
  if (/mcp.?server|mcp.?error/i.test(t)) signals.push('mcp_server_error');
  if (/fatal:|git\s+(clone|pull|push|merge|rebase|checkout)/i.test(msg) && /fatal|error|conflict/i.test(t)) signals.push('git_error');
  if (/traceback|python|syntaxerror|typeerror|importerror|modulenotfound/i.test(t)) signals.push('python_error');
  if (/npm\s+err|node_modules|package\.json/i.test(t)) signals.push('npm_error');
  if (signals.length === 0 && (t.includes('error') || t.includes('fail') || t.includes('fatal'))) signals.push('unknown_error');
  return [...new Set(signals)];
}

// ── 环境指纹快照 ──
function collectEnvFingerprint() {
  let pythonVersion = null;
  let gitVersion = null;
  let npmRegistry = null;
  try { pythonVersion = execFileSync('python3', ['--version'], { encoding: 'utf-8', timeout: 3000 }).trim().replace(/^python\s+/i, ''); } catch {}
  try { gitVersion = execFileSync('git', ['--version'], { encoding: 'utf-8', timeout: 3000 }).trim().replace(/^git version\s+/i, ''); } catch {}
  try { npmRegistry = execFileSync('npm', ['config', 'get', 'registry'], { encoding: 'utf-8', timeout: 3000 }).trim(); } catch {}

  let totalMemoryGB = 0;
  try {
    const bytes = parseInt(execFileSync('sysctl', ['-n', 'hw.memsize'], { encoding: 'utf-8', timeout: 3000 }).trim(), 10);
    if (!isNaN(bytes)) totalMemoryGB = Math.round(bytes / 1024 ** 3);
  } catch {}

  return {
    os: `${process.platform} ${process.arch}`,
    arch: process.arch,
    totalMemoryGB,
    nodeVersion: process.version,
    pythonVersion,
    gitVersion,
    npmRegistry: npmRegistry || null,
    shellProxy: process.env.SHELL_PROXY || null,
    httpProxy: process.env.HTTP_PROXY || process.env.http_proxy || null,
    httpsProxy: process.env.HTTPS_PROXY || process.env.https_proxy || null,
    claudeVersion: process.env.CLAUDE_CODE_VERSION || null,
    cwdHash: shortHash(process.cwd()),
  };
}

// Experience patterns (same as agent-lite)
const EXPERIENCE_PATTERNS = [
  { patterns: ['ModuleNotFoundError', 'No module named', 'ImportError'], title: 'Python 模块缺失', advice: '安装缺失的 Python 依赖', commands: ['pip install <module>', 'pip3 install <module>'] },
  { patterns: ['SyntaxError:', 'IndentationError', 'TabError'], title: 'Python 语法错误', advice: '检查 Python 代码缩进和语法', commands: ['python3 -m py_compile <file>'] },
  { patterns: ['TypeError:', 'AttributeError:', 'KeyError:', 'ValueError:'], title: 'Python 运行时错误', advice: '检查数据类型和属性访问', commands: [] },
  { patterns: ['alembic'], title: 'Alembic 数据库迁移工具缺失', advice: '安装 alembic', commands: ['pip install alembic', 'pip3 install alembic'] },
  { patterns: ['Permission denied', 'EACCES', 'operation not permitted'], title: '权限错误', advice: '需要提升权限或检查文件权限', commands: ['ls -la', 'sudo <cmd>'] },
  { patterns: ['ECONNREFUSED', 'Connection refused'], title: '连接被拒绝', advice: '检查服务是否运行，或网络是否正常', commands: [] },
  { patterns: ['ETIMEDOUT', 'Timed out'], title: '连接超时', advice: '网络连接超时，稍后重试', commands: [] },
  { patterns: ['MCP server error', 'mcp server', 'MCP error'], title: 'MCP 服务器错误', advice: 'MCP 服务器连接失败，检查配置和日志', commands: [] },
  { patterns: ['unknown flag:', 'invalid option', 'Unknown skill:'], title: '命令参数错误', advice: '命令参数不正确，检查帮助信息', commands: ['<cmd> --help'] },
  { patterns: ['fatal:', 'not an empty directory', 'needs merge'], title: 'Git 操作错误', advice: '检查 git 仓库状态', commands: ['git status', 'git pull --rebase'] },
  { patterns: ['command not found', 'not found:', 'ENOENT'], title: '命令不存在', advice: '请安装缺失的命令，或检查 PATH', commands: ['which <cmd>', 'brew install <pkg>'] },
  { patterns: ['Traceback', 'most recent call last'], title: '代码执行错误', advice: '查看上方堆栈跟踪定位错误位置', commands: [] },
  { patterns: ['GraphQL:', 'GitHub API'], title: 'GitHub API 错误', advice: '检查 GitHub 认证状态和网络连接', commands: ['gh auth status'] },
  { patterns: ['npm', 'node_modules', 'package.json'], title: 'Node.js 项目问题', advice: '检查 Node.js 环境', commands: ['npm install', 'node --version'] },
  { patterns: ['git'], title: 'Git 错误', advice: '检查 git 仓库状态', commands: ['git status', 'git log'] },
];

function lookupExperience(message) {
  for (const exp of EXPERIENCE_PATTERNS) {
    for (const pattern of exp.patterns) {
      if (message.toLowerCase().includes(pattern.toLowerCase())) {
        return { title: exp.title, advice: exp.advice, commands: exp.commands || [] };
      }
    }
  }
  return null;
}


// Read payload from stdin
let payload = '';
process.stdin.on('data', (chunk) => {
  payload += chunk.toString();
});

process.stdin.on('end', () => {
  try {
    const data = JSON.parse(payload);
    handleToolResult(data);
  } catch (e) {
    // Silent exit on parse error - don't block Claude Code
    process.exit(0);
  }
});

function handleToolResult(data) {
  // Only handle Bash and Agent tools
  if (!['bash', 'agent', 'task', 'bashcon'].some(t => data.toolName?.toLowerCase().includes(t))) {
    return;
  }

  // Extract command info from tool input
  const toolInput = data.toolInput || data.tool_input || {};
  const command = String(toolInput.command || '').slice(0, 500);
  const commandCategory = classifyCommand(command);
  const exitCode = data.exitCode;
  const hasTimeout = /timeout|timed.?out/i.test(String(data.error || data.toolOutput?.stderr || ''));
  const exitStatus = hasTimeout ? 'timeout' : (exitCode === undefined || exitCode === null) ? 'success' : (exitCode === 0 ? 'success' : 'failure');

  // Build command audit record
  const commandAudit = command ? {
    command: command.slice(0, 500),
    category: commandCategory,
    exitStatus,
    exitCode: exitCode !== undefined ? exitCode : undefined,
  } : undefined;

  // Check for errors
  const errorMsg = data.error || data.toolOutput?.stderr || data.toolOutput?.error || '';

  // No error = skip (but still log successful commands for audit)
  if (!errorMsg && exitCode === 0) {
    return;
  }

  // Noise patterns to filter out
  const NOISE_PATTERNS = [
    /Input must be provided either through stdin or as a prompt argument when using --print/i,
    /^Error: Input must be provided/i,
  ];

  if (NOISE_PATTERNS.some(p => p.test(errorMsg))) {
    return;
  }

  // Skip if no meaningful error message
  if (!errorMsg.trim()) {
    return;
  }

  // Extract semantic error signals
  const errorSignals = extractErrorSignals(errorMsg);

  // Collect environment fingerprint
  const envFingerprint = collectEnvFingerprint();

  const fingerprint = shortHash(`${data.toolName}\n${errorMsg.replace(/\d+/g, '<N>')}`);

  // Build tool context from Claude Code hook input
  const toolContext = { toolName: data.toolName || 'unknown' };
  if (command) toolContext.command = command;
  if (toolInput.file_path) toolContext.filePath = String(toolInput.file_path).slice(0, 300);
  const workingDir = String(
    toolInput.cwd || toolInput.working_directory || data.cwd || process.cwd() || ''
  ).trim();
  if (workingDir) toolContext.cwd = workingDir.slice(0, 300);
  if (exitCode !== undefined) toolContext.exitCode = exitCode;

  // Create event
  const event = {
    schemaVersion: 2,
    eventId: `evt_${Date.now()}_${Math.random().toString(36).slice(2)}`,
    clientId: 'hook',
    deviceId: 'hook',
    source: 'mac-aicheck-post-tool-hook',
    agent: 'claude-code',
    eventType: 'post_tool_error',
    occurredAt: nowIso(),
    fingerprint,
    sanitizedMessage: errorMsg.slice(0, 8000),
    severity: 'error',
    localContext: {
      os: `${process.platform} ${process.release}`,
      shell: process.env.SHELL || '',
      node: process.version,
      cwdHash: shortHash(process.cwd()),
    },
    toolContext: toolContext,
    error_signals: errorSignals.length > 0 ? errorSignals : undefined,
    command_audit: commandAudit,
    env_fingerprint: envFingerprint,
    syncStatus: 'pending'
  };

  // Store event
  ensureDir(join(BASE_DIR, 'outbox'));
  ensureDir(DAILY_DIR);
  appendFileSync(OUTBOX_FILE, JSON.stringify(event) + '\n');

    // Update daily pack
  const dateFile = join(DAILY_DIR, `${today()}.json`);

  const defaultPack = {
    date: today(),
    totalEvents: 0,
    uniqueFingerprints: 0,
    repeatedEvents: 0,
    fixedEvents: 0,
    consecutiveFailures: 0,
    lastFailureFingerprint: null,
    lastEventAt: null,
    topProblems: [],
  };

  let pack = defaultPack;
  try {
    if (existsSync(dateFile)) {
      pack = JSON.parse(readFileSync(dateFile, 'utf8'));
    }
  } catch (e) {}

  pack.totalEvents++;
  pack.lastEventAt = event.occurredAt;

  if (pack.lastFailureFingerprint === fingerprint) {
    pack.consecutiveFailures++;
  } else {
    pack.consecutiveFailures = 1;
    pack.lastFailureFingerprint = fingerprint;
  }

  const existingProblem = pack.topProblems.find(p => p.fingerprint === fingerprint);
  if (existingProblem) {
    existingProblem.count++;
    existingProblem.status = 'repeated';
    pack.repeatedEvents++;
  } else {
    pack.topProblems.push({
      fingerprint,
      title: errorMsg.split('\n')[0].slice(0, 120) || event.eventType,
      count: 1,
      status: 'new',
    });
  }
  pack.uniqueFingerprints = pack.topProblems.length;
  pack.topProblems.sort((a, b) => b.count - a.count);

  writeFileSync(dateFile, JSON.stringify(pack, null, 2));

  // Lookup and display experience advice
  const exp = lookupExperience(errorMsg);
  if (exp) {
    // Append to experience log
    appendFileSync(EXPERIENCE_FILE, JSON.stringify({
      fingerprint,
      eventType: event.eventType,
      title: exp.title,
      advice: exp.advice,
      commands: exp.commands,
      happenedAt: nowIso(),
      resolved: false,
    }) + '\n');

    // Output advice to stderr (will be shown to user)
    process.stderr.write(`\n💡 mac-aicheck 经验库建议:\n`);
    process.stderr.write(`   ${exp.title}\n`);
    process.stderr.write(`   ${exp.advice}\n`);
    if (exp.commands.length > 0) {
      process.stderr.write(`   可尝试: ${exp.commands.join(' | ')}\n`);
    }
  }

  // Output summary with command classification and error signals
  const parts = [`mac-aicheck: 已记录问题 ${event.eventId}`];
  if (commandCategory !== 'unknown') parts.push(`命令类型: ${commandCategory}`);
  if (errorSignals.length > 0) parts.push(`错误信号: ${errorSignals.join(', ')}`);
  process.stderr.write(`\n${parts.join(' | ')}\n`);
}

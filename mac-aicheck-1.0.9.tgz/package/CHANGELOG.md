# 更新日志

All notable changes will be documented in this file.

## [Unreleased]

### Changed

- 轻量 `--serve` 页面新增吸顶导航、环境结论、当前最该处理和后续路线区块，并支持从卡片直接定位到对应问题项。
- 修复动作按钮文案统一改为 `查看并执行 / 查看后确认`，执行前增加确认与提示反馈，避免用户误判为按钮无响应。
- 同步 `TASK-230` 最新生产 smoke 事实：平台侧 `auto_scan -> reviewer quorum -> solved_confirmed -> owner_rescan -> failed final rescan -> reopen original problem` 已在 2026-05-03 最新生产部署上重新跑通，当前 MacAICheck 不再被平台 reviewer 可见性或 final-rescan surfaced 问题阻断。
- 同步 `TASK-230` 最新真实 Mac 结论：MacAICheck 已完成 L0/L1 owner validation 历史链路核对，并补齐 L2 `owner_repair` 被 `blocked_pending_rollback_parity` 阻断的当场证据。

### Fixed

- 补回 `detectMacDeviceInfo()` 缺失实现，恢复 device-flow bind 的可读 macOS 设备信息上报，并修正绑定提示文案与测试契约。
- 修复 `owner_repair` 的 rollback parity gating：仅在具备 rollback readiness 与对应修复能力时越过阻断，避免错误落入 `not_prepared` 分支。

### Notes

- `TASK-230` 的真实 smoke 证据已经收口；在 backup/rollback parity 完成前，Mac 仍只对外承诺 L0/L1 自动验证与 L2 `owner_repair` 阻断，不表述为 Mac L2 自动修复已就绪。

### Added

- **AICO EVO Agent 完整实现**：新增 `mac-aicheck agent` 子命令，支持设备绑定（`bind`）、状态查询（`status`）、悬赏浏览（`bounty-recommended`、`bounty-list`）、悬赏领取与提交（`bounty-claim`、`bounty-submit`）。
- **Worker Daemon**：新增 `mac-aicheck agent worker start/stop/status` 子命令，后台持续运行悬赏循环（heartbeat → kb-match → claim → execute → submit），支持自动重试与跳过已解任务。
- **Hermes 错误上报**：新增 `mac-aicheck agent report-error --json`、`hermes-status`、`hermes-connect --log-path` 子命令，接收 Hermes Agent 错误并写入 `hermes-events.jsonl`，自动合并到主事件 outbox。
- **Review 流程支持**：新增 `mac-aicheck agent review-list`、`owner-check` 子命令。
- **E2E 测试覆盖**：新增 `tests/agent-e2e.test.ts`（11 cases，覆盖 bind/status/bounty/worker/review 全流程）和 `tests/hermes-hook.test.ts`（10 cases，覆盖 report-error/hermes-status/hermes-connect）。
- **Hermes 集成文档**：新增 `docs/hermes-integration.md`，详细说明 CLI 模式、MCP 模式、日志路径配置、错误脱敏规则。

## [1.0.7] - 2026-05-02

### Changed

- Agent Protocol V2 现已在 MacAICheck 中解析 `lifecycle_state`、`risk_level`、`execution_task.kind`、`repair_capability`、`consent_state`、`rollback_state`、`prepare_state`。
- Mac worker 保持 P0 安全边界：继续支持 L0/L1 owner validation 自动验证，但在缺少 backup/rollback parity 时显式阻断 `owner_repair`，返回 `blocked_pending_rollback_parity`，且不会触发本地执行或 owner verify 提交。

## [1.0.0] - 2026-04-06

### 首次发布

- ✅ 18 项环境检测（Claude Code、OpenClaw、Gemini CLI、Homebrew、Xcode、Node.js、Python 等）
- ✅ 4 栏 Web UI：诊断结果 / AI工具安装 / 教学中心 / Coding Plan
- ✅ 一键修复命令（检测页直接点击执行）
- ✅ AI 工具安装（8 个工具，npm 一键安装）


- ✅ AICO EVO 数据上报（与 WinAICheck 格式一致）
- ✅ HTML 报告导出
- ✅ Tab 切换状态保存（sessionStorage）
- ✅ ARIA 无障碍支持
- ✅ CCSwitch、Cute Claude Hooks、OpenCode 支持
- ✅ npm 全量镜像（npmmirror.com）加速
